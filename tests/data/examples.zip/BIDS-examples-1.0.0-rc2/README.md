# BIDS-examples
A set of BIDS compatible datasets with empty nifti files that can be used for testing software.
